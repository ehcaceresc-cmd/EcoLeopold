# EcoLeopold

Matriz de Leopold digital para Evaluación de Impacto Ambiental (EIA), con EcoNormas (chequeo contra los ECA de Perú).

- Elige proyecto: carretera, relleno sanitario, mina, planta de tratamiento o edificio.
- Activa acciones y factores ambientales; edita Magnitud (-10 a +10) e Importancia (1 a 10) en cada casilla.
- Cálculo automático: Σ por factor, Σ por acción, impacto total e índice (-100 a +100).
- Matriz coloreada en vivo, gráficos de barras, distribución de impactos y ranking.
- Medidas de mitigación sugeridas para impactos severos o críticos.
- EcoNormas: compara tus valores con ECA Aire, Agua y Ruido.
- Descarga de reporte (HTML), matriz (CSV) y código de proyecto para compartir.

## Usar
Es una sola página sin dependencias de compilación. Abre `index.html` en el navegador.

## Publicar en GitHub Pages
1. Crea un repositorio y sube `index.html` y `README.md`.
2. En Settings → Pages, elige la rama `main` y la carpeta `/ (root)`.
3. Tu enlace para compartir será `https://TU-USUARIO.github.io/NOMBRE-DEL-REPO/`.

## Nota
Los límites ECA son de referencia (D.S. 003-2017-MINAM, D.S. 004-2017-MINAM, D.S. 085-2003-PCM). Verifica con la norma vigente antes de presentar. El criterio de viabilidad es didáctico.
